#include "mycp.h"

/**
 * @brief Copies the content of a source file to a destination file,
 * with respect to the provided copy settings.
 *
 * @param src The path to the source file that will be copied.
 * @param dest The path to the destination file where the content of the
 * source file will be written.
 * @param settings A 'CopySettings' struct containing flags that modify the
 * copying behavior.
 * @return 0 on successful completion, -1 on error.
 */
int copy_file(const char *src, const char *dest, CopySettings settings) {
    // STEP 2: Check if the destination file exists and the 'force' flag is not set.
    if (file_exists(dest) && !settings.force) {
        fprintf(stderr, "Destination file exists. Use -f to force overwrite.\n");
        return -1;
    }
    
    // STEP 3: Open the source file for reading.
    int src_fd = open_file(src, O_RDONLY, 0);
    if (src_fd < 0) {
        return -1;  // Error already printed by open_file
    }
    
    // STEP 4: Open the destination file for writing.
    int dest_fd = open_file(dest, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (dest_fd < 0) {
        close_file(src_fd);  // Close the source file first
        return -1;  // Error already printed by open_file
    }
    
    // STEP 5: Read from source and write to destination in a loop.
    char buffer[1024];
    ssize_t bytes_read;
    
    while ((bytes_read = read_file(src_fd, buffer, sizeof(buffer))) > 0) {
        // STEP 6: Write the read data to the destination file.
        ssize_t bytes_written = write_file(dest_fd, buffer, bytes_read);
        if (bytes_written < 0) {
            close_file(src_fd);
            close_file(dest_fd);
            return -1;  // Error already printed by write_file
        }
    }
    
    // STEP 7: Close the file descriptors.
    close_file(src_fd);
    close_file(dest_fd);
    
    // If all operations are successful, return 0.
    return 0;
}
