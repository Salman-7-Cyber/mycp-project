#!/bin/bash

# --------------------------------------------
# test_copy.sh
# Shell script to test the mycp program
# --------------------------------------------

# Step 1: Create a new text file called source.txt
echo "Hello SEC2323!.... this is a test" > source.txt
echo "Created source.txt with test content"

# Step 2: Use mycp program to copy source.txt to copied.txt
echo "Copying source.txt to copied.txt using mycp"
./mycp -f source.txt copied.txt

# Step 3: Compare the two files to see if the copy was successful
echo "Comparing source.txt and copied.txt..."
diff source.txt copied.txt

# Step 4: Check the result of the comparison
if [ $? -eq 0 ]; then
    echo "Test passed! Files are identical."
else
    echo "Test failed! Files are different."
fi

# Clean up
echo "Test complete. You can examine source.txt and copied.txt"
