#include "mycp.h"

// This function prints the usage instructions for the 'mycp' program.
void print_usage(const char *prog_name) {
    fprintf(stderr, "Usage: %s [-f] [-p] source_file destination_file\n", prog_name);
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "  -f    Force overwrite if destination file exists\n");
    fprintf(stderr, "  -p    Preserve file metadata\n");
}

// The main function of the 'mycp' program. It parses command-line arguments
// and calls the 'copy_file' function.
int main(int argc, char *argv[]) {
    // Check if the number of command-line arguments is less than 3
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }

    // Initialize settings and file path pointers
    CopySettings settings = {0, 0};  // force = 0, preserve = 0
    const char *src = NULL;
    const char *dest = NULL;
    
    // Parse command-line arguments
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-f") == 0) {
            settings.force = 1;
        } else if (strcmp(argv[i], "-p") == 0) {
            settings.preserve = 1;
        } else if (src == NULL) {
            src = argv[i];
        } else if (dest == NULL) {
            dest = argv[i];
        }
    }
    
    // Ensure both source and destination files were provided
    if (src == NULL || dest == NULL) {
        print_usage(argv[0]);
        return 1;
    }
    
    // Call the copy_file function with parsed arguments
    return copy_file(src, dest, settings);
}
