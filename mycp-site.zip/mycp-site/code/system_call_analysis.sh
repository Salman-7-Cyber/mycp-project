#!/bin/bash

# --------------------------------------------
# system_call_analysis.sh
# Script to compare system calls made by mycp and cp
# --------------------------------------------

# Step 1: Print a message saying you're tracing mycp
echo "Running system call trace for mycp..."

# Step 2: Use strace to trace the system calls made by ./mycp
strace -c -f ./mycp -f file1.txt file2.txt > /dev/null 2> mycp_trace.txt

# Step 3: Print a message saying you're tracing cp
echo "Running system call trace for cp..."

# Step 4: Use strace to trace the standard cp command
strace -c -f cp -f file1.txt file2.txt > /dev/null 2> cp_trace.txt

# Step 5: Print a message confirming that the traces were saved
echo "Traces completed. Results saved in mycp_trace.txt and cp_trace.txt"
echo "You can now analyze the differences between the two commands."
