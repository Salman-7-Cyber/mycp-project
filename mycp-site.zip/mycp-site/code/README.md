# File Copy Utility Project - mycp

This project implements a simple file copy utility (mycp) in C using system calls. The utility allows copying files with options to force overwrite and preserve metadata.

## Project Design

### How mycp Works

The `mycp` utility is designed to copy files using low-level system calls. It operates in the following way:

1. **Command-Line Parsing**: The program accepts command-line arguments including options (`-f` for force overwrite, `-p` for preserving metadata) and source/destination file paths.

2. **File Operations**: The core functionality is implemented using the following system calls:
   - `open()`: To open source and destination files
   - `read()`: To read data from the source file
   - `write()`: To write data to the destination file
   - `close()`: To close file descriptors
   - `access()`: To check if files exist

3. **Data Transfer**: The program reads data in blocks (1024 bytes at a time) from the source file and writes it to the destination file, ensuring efficient memory usage.

4. **Error Handling**: The program includes comprehensive error handling using `perror()` to report system call failures.

### System Calls Used

The following system calls are used in our implementation:
- `open()`
- `read()`
- `write()`
- `close()`
- `access()`

## Comparison of mycp vs. cp System Calls

After using the `system_call_analysis.sh` script to compare `mycp` with the standard `cp` command, we observed the following:

1. **System Call Count**: Our `mycp` implementation uses fewer system calls compared to the standard `cp` command.

2. **Key Differences**:
   - The standard `cp` command performs additional checks like file permissions and ownership.
   - Standard `cp` uses more advanced features like memory mapping when appropriate.
   - Our `mycp` implementation focuses on the core functionality of file copying.

## Valgrind Analysis

We used Valgrind to check for memory issues in our implementation.

```
valgrind --leak-check=full ./mycp -f file1.txt file2.txt
```

**Results**:
- No memory leaks were detected
- No invalid memory accesses or undefined behavior
- The program properly allocates and frees all resources

This confirms that our implementation efficiently manages memory without leaks or illegal operations.

## Development Challenges

During development, we faced the following challenges:

1. **Error Handling**: Ensuring comprehensive error handling for system calls was challenging. We addressed this by wrapping system calls in functions that check return values and use `perror()` for error reporting.

2. **Command-Line Argument Parsing**: Correctly parsing different combinations of options and file paths required careful programming. We implemented a solution that checks each argument individually.

3. **File Overwrite Logic**: Implementing the logic to check if a destination file exists and handling the force overwrite option required careful consideration of edge cases.

## Team Member Contributions

- **Member 1**: Implemented file_ops.c functions and wrote the Makefile
- **Member 2**: Developed the core copy_file function in mycp.c 
- **Member 3**: Created the main.c file for command-line parsing and wrote the test scripts
- **Member 4**: Performed testing, documented the project, and created README.md

## How to Run the Project

1. **Compile the Program**:
   ```
   make
   ```

2. **Run the Copy Utility**:
   ```
   ./mycp [-f] [-p] source_file destination_file
   ```
   Options:
   - `-f`: Force overwrite if destination file exists
   - `-p`: Preserve file metadata

3. **Run Tests**:
   ```
   ./test_copy.sh
   ```

4. **Analyze System Calls**:
   ```
   ./system_call_analysis.sh
   ```

5. **Clean Build Files**:
   ```
   make clean
   ```
